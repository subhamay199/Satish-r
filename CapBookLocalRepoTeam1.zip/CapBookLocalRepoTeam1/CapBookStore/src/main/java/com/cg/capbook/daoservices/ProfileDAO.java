package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;

public class ProfileDAO {

}
