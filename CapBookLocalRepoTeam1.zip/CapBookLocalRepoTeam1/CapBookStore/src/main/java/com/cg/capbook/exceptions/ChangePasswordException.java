package com.cg.capbook.exceptions;

public class ChangePasswordException  extends Exception{

	public ChangePasswordException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ChangePasswordException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ChangePasswordException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ChangePasswordException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ChangePasswordException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
